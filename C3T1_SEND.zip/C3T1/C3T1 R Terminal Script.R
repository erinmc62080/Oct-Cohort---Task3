library(readr)
carsdata<- read.csv("C:\UTOCT20\COURSE 3 RSTUDIO\C3T1\R Tutorial Data Sets\carsdata.csv file")
carsdata<-read.csv("R Tutorial Data Sets/carsdata.csv")
attributes(carsdata)
summary(carsdata)
str(carsdata)
names(carsdata)
carsdata$name.of.car
#PLOTTING - columns MUST BE NUMERIC FOR NEXT TWO PLOTS 
hist(carsdata$speed.of.car)
#median speed occurs the most, min speed occurs the least, highest speed occurs more than lowest but lower than median
plot(carsdata$speed.of.car,carsdata$distance.of.car)
#CHANGING data type for name.of.car to factor from character 
carsdata$name.of.car<-as.factor(carsdata$name.of.car)
#checking data structure now 
str(carsdata)
#RENAMING columns for easier processing 
names(carsdata)<-c("veh type","speed","distance") 
#looking at data to make sure changes occurred 
names(carsdata)
#LOOKING for N/A's 
summary(carsdata)
is.na(carsdata)
#NO N/A's
#CREATING TRAINING AND TEST SETS 
set.seed(123)
trainSize<-round(nrow(carsdata)*0.7)
testSize<-nrow(carsdata)-trainSize
#TWO data sets needed for modeling. One is TRAINING set and the other is TEST set 
#common split is 70/30 - 70% for TRAINING & 30% for TESTING
#The trainSize lines only CALCULATE the size of each set - they DO NOT CREATE the set
#REVIEWING the instances within each set 
trainSize
testSize
#NOW WE WILL CREATE THE TRAIN AND TEST SETS - we need these in randomized order for optimal modeling performance 
training_indices<-sample(seq_len(nrow(carsdata)),size =trainSize)
trainSet<-carsdata[training_indices,]
testSet<-carsdata[-training_indices,]
#CREATING LINEAR REGRESSION MODEL
#LINEAR REGRESSION is helpful in trying to determine relationship between two variables ( X& y)
#X is the indep variable - it's independent because it doesn't depend on other attributes while making predictions 
#Y is the response variable because IT depends on other variables 
#we are trying to predict distance, therefore that will be our dep variable. Speed is the indep variable
#In other words: is the distance a car can travel contingent on the speed of the car?
linmod<-lm(distance~ speed, trainSet)
summary(linmod)
#PREDICTIONS 
linmodpreds<-predict(linmod, testSet)
linmodpreds
#Rsquared is 0.92 which indicates the model fit the data well
#Rsquared is the statistical measure of how close the data points are to the fitted regression line
predict(linmod, newdata=carsdata, interval = 'confidence')
#FINDING ERRORS#
#CALL ON MY LIBRARY
library(readr)
#IMPORT DATASET
irisdata<-read.csv("R Tutorial Data Sets/iris.csv")
#REVIEW DATA STRUCTURE
attributes(irisdata)
#what is column X?
summary(irisdata)
str(irisdata)
names(irisdata)
#will try to drop column X 
irisdataclean=subset(irisdata, select = -c(X))
str(irisdataclean)
#USE IRISDATACLEAN from now on as unneeded column removed#
str(irisdataclean)
#need to change species into character format
irisdataclean$Species<-as.factor(irisdataclean$Species)
#make sure that was successful
str(irisdataclean)
hist(irisdataclean$Sepal.Length)
summary(irisdataclean)
#predicting the petals length (y) using the petals width (x)
#renaming my columns to make life easier 
names(irisdataclean)<-c("sepal length","sepal width","petal length", "petal width","species")
names(irisdataclean)
plot(irisdataclean$`petal length`)
hist(irisdataclean$`petal length`)
summary(irisdataclean)
#summary shows the lowest petal length is 1  with the longest 6.9
#histogram also show the min value for length occurs the most within the dataset, and the longest length occurs the least
qqnorm(irisdatasetclean$petalwidth)
qqnorm(irisdataclean$`petal width`)
irisdataclean$species<-as.numeric(irisdataclean$species)
str(irisdataclean)
set.seed(123)
trainSize<-round(nrow(irisdataclean)*0.7)
testSize<-nrow(irisdataclean)-trainSize 
trainSize
testSize
set.seed(405)
trainSet <- irisdataclean[training_indices, ]
testSet <- irisdataclean[-training_indices, ]
irismodel<-lm(trainSet$`petal width`~trainSet$`petal length`)
summary(irismodel)
irisprediction<-predict(irismodel, trainSet)
irisprediction
#COMPLETED TASK 1##WE WILL TEST MODEL IN TASK2, SO FAR WE HAVE JUST TRAINED#